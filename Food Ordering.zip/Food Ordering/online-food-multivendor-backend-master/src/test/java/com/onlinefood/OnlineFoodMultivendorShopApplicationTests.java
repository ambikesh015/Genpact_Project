package com.onlinefood;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineFoodMultivendorShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
